# Dogs, Cats and Birds > 2025-04-12 2:46am
https://universe.roboflow.com/zero-okhjh/dogs-cats-and-birds-dltz4

Provided by a Roboflow user
License: CC BY 4.0

Model for detecting dogs, cats and birds. Images and labels taken from Google Open Images Dataset V7